# quantum-telescoping-sims

Reference repository for **Quantum Telescoping Part X: Experimental and NISQ Limits of Telescoping Convergence**.

This repository provides simulation and analytic code supporting the paper, including:
- Pareto frontier / optimal depth visualization
- Suzuki-2 telescoping saturation under depolarizing noise
- Statistical confirmation via repeated noisy runs

The code is intended to illustrate scaling and saturation behavior predicted by theory,
not to provide hardware-specific performance claims.
